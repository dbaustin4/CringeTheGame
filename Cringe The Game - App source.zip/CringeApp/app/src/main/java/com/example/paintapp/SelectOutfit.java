package com.example.paintapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class SelectOutfit extends AppCompatActivity {

    ArrayList<ImageView> bodyImages;
    Bitmap[] hImages, bImages, lImages;

    private int hIndex, bIndex, lIndex = 0;
    private int selectedImage = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_outfit_select);

        bodyImages = new ArrayList<ImageView>();
        bodyImages.add(findViewById(R.id.ivHead));
        bodyImages.add(findViewById(R.id.ivBody));
        bodyImages.add(findViewById(R.id.ivLegs));

        setInitialImages();
    }

    private void setInitialImages() {

        hImages = new Bitmap[]{
                BitmapFactory.decodeResource(getResources(), R.drawable.head),
                BitmapFactory.decodeResource(getResources(), R.drawable.head2),
                BitmapFactory.decodeResource(getResources(), R.drawable.head3),
                BitmapFactory.decodeResource(getResources(), R.drawable.head4),
                BitmapFactory.decodeResource(getResources(), R.drawable.head5),
                BitmapFactory.decodeResource(getResources(), R.drawable.head6)
        };

        bImages = new Bitmap[] {
                BitmapFactory.decodeResource(getResources(), R.drawable.body),
                BitmapFactory.decodeResource(getResources(), R.drawable.body1),
                BitmapFactory.decodeResource(getResources(), R.drawable.body2),
                BitmapFactory.decodeResource(getResources(), R.drawable.body3),
                BitmapFactory.decodeResource(getResources(), R.drawable.body4)
        };

        lImages = new Bitmap[] {
                BitmapFactory.decodeResource(getResources(), R.drawable.legs),
                BitmapFactory.decodeResource(getResources(), R.drawable.legs1),
                BitmapFactory.decodeResource(getResources(), R.drawable.legs2),
                BitmapFactory.decodeResource(getResources(), R.drawable.legs3),
                BitmapFactory.decodeResource(getResources(), R.drawable.legs4),
                BitmapFactory.decodeResource(getResources(), R.drawable.legs5),
        };

        for(int i=0; i<bodyImages.size(); i++)
        {
            ImageView imgV = bodyImages.get(i);
            if(i==0)
            {
                imgV.setImageBitmap(hImages[0]);
            }
            else if(i==1) {
                imgV.setImageBitmap(bImages[0]);
            }
            else {
                imgV.setImageBitmap(lImages[0]);
            }
        }
    }

    private void handleClicksImageView(int indexToEnable) {
        selectedImage = indexToEnable;

        for(int i=0; i<bodyImages.size(); i++)
        {
            ImageView imgV = bodyImages.get(i);
            if(i==indexToEnable)
            {
                imgV.setBackgroundResource(R.drawable.frame_image_view);
            }
            else
            {
                imgV.setBackgroundResource(android.R.color.transparent);
            }
        }
    }

    public void imageSelection(View view)
    {
        handleClicksImageView(this.bodyImages.indexOf((ImageView) view));
    }

    public void changeRight(View view) {
        switch(selectedImage){
            case 0:
                hIndex++;
                if(hIndex >= hImages.length-1) {
                    hIndex = hImages.length-1;
                }
                this.bodyImages.get(selectedImage).setImageBitmap(hImages[hIndex]);
                break;
            case 1:
                bIndex++;
                if(bIndex >= bImages.length-1) {
                    bIndex = bImages.length-1;
                }
                this.bodyImages.get(selectedImage).setImageBitmap(bImages[bIndex]);
                break;
            case 2:
                lIndex++;
                if(lIndex >= lImages.length-1) {
                    lIndex = lImages.length-1;
                }
                this.bodyImages.get(selectedImage).setImageBitmap(lImages[lIndex]);
                break;
            default:

        }
    }

    public void changeLeft(View view) {
        switch(selectedImage){
            case 0:
                hIndex--;
                if(hIndex <= 0) {
                    hIndex = 0;
                }
                this.bodyImages.get(selectedImage).setImageBitmap(hImages[hIndex]);
                break;
            case 1:
                bIndex--;
                if(bIndex <=0) {
                    bIndex = 0;
                }
                this.bodyImages.get(selectedImage).setImageBitmap(bImages[bIndex]);
                break;
            case 2:
                lIndex--;
                if(lIndex <=0) {
                    lIndex = 0;
                }
                this.bodyImages.get(selectedImage).setImageBitmap(lImages[lIndex]);
                break;
            default:

        }
    }

    public void onClickConfirm(View view){
        {
            Toast.makeText(SelectOutfit.this, "Outfit Saved", Toast.LENGTH_LONG).show();

            // Allow the user in to your app by going into the next activity
            startActivity(new Intent(SelectOutfit.this, confirm.class));
        }
    }
}