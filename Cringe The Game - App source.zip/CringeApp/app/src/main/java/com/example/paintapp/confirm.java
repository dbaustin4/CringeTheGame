package com.example.paintapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class confirm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm);
    }
}