package com.example.paintapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

//stuff for conection

import com.example.paintapp.downloadtask.GetPersons;
import com.example.paintapp.downloadtask.PostPersons;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    //global variables
    public int login_id;

    public String ip = "https://192.168.1.6:3434";
    public String login_data_r = "/login_data";
    public String get_id_db = "/get_id_login";

    private EditText e_mail;
    private EditText password;

    JSONArray id = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        e_mail = findViewById(R.id.etName);
        password = findViewById(R.id.etPassword);

    }//end on create

    public void login_btn(View v)
    {
        try {
            // -------------> POST DATA
            Map<String, String> postData = new HashMap<>();
            postData.put("email", "teste@teste.com");
            postData.put("password", "teste123");

            PostPersons task = new PostPersons(postData);

            id = task.execute(""+ip+login_data_r+get_id_db).get();
            Log.i("test" , id.toString());

        } catch (Exception e) {
            e.printStackTrace();
            id = null;
            Log.i("error" , "this died");
        }
    }

    }//end class